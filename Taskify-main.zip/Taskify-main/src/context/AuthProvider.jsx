import React, { useEffect, useState } from 'react'
import { createContext } from 'react'
import { getLocalStorage, setLocalStorage } from '../utils/LocalStorage'

// create context --> centralised data 
export const AuthContext = createContext()

const AuthProvider = ({children}) => {
    const [userData, setUserData] = useState(null)

    
    useEffect(() => {
        // localStorage.clear()

        setLocalStorage() 
        const {employees}=getLocalStorage()    //getting data 
        setUserData(employees)         //setting data 
    },[])
    
    // dataa provider bngya he ye 
  return (
    <div>
      <AuthContext.Provider value={[userData,setUserData]}>
        {children}
      </AuthContext.Provider>
    </div>
  )
}

export default AuthProvider
