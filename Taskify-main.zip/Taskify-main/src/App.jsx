import React, { useContext, useEffect, useState } from 'react'
import Login from './components/Auth/Login'
import EmployeeDashboard from './components/Dashboard/EmployeeDashboard'
import AdminDashboard from './components/Dashboard/AdminDashboard'
import { getLocalStorage, setLocalStorage } from './utils/LocalStorage'
import { AuthContext } from './context/AuthProvider'

const App = () => {
  // useeffect to set the data 
  // main stack ke side me ek function run krwata he 
  // useEffect(() => {
  //   // setLocalStorage(); 
  //   getLocalStorage();
  // },)

  const [user, setUser]=useState(null)
  const [loggedInUserData,setLoggedInUserData]=useState(null)
  // data consume krrha he yha 
  const [userData,setUserData] = useContext(AuthContext)
  

  // to solve the login problem -->  baar baar reload pr logout ho rha he  
  useEffect(() => {
    const loggedInUser = localStorage.getItem('loggedInUser')
    
    if(loggedInUser){
      const userData=JSON.parse(loggedInUser)
      setUser(userData.role)
      setLoggedInUserData(userData.data)
      console.log(userData)

    }
  }, [])
  
  


  // validate login
  const handleLogin=(email,password)=>{
    if(email== 'admin@me.com' && password=='123'){
      setUser('admin')
      localStorage.setItem('loggedInUser',JSON.stringify({role:'admin'}))
      
    }
    // if there is data in the auth data and if it matches with the stored data then setuser as employee
    else if(userData){
      const employees = userData.find((e)=>email == e.email && password==e.password)
      if(employees){
        setUser('employees')
        setLoggedInUserData(employees)
        localStorage.setItem('loggedInUser',JSON.stringify({role:'employees',data:employees}))
      }  
    }
    else{
      alert("Invalid Credentials")
    }
  }
  


  return (
    <>
      {!user ? <Login handleLogin={handleLogin}/>:''}  
      {user=='admin' ? <AdminDashboard changeUser={setUser}/>:''}
      {user=='employees' ? <EmployeeDashboard data={loggedInUserData}changeUser={setUser}/>:''}
       
    </>
  )
}

export default App
