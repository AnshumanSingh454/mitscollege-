import React, { useContext, useEffect, useState } from 'react'
import { AuthContext } from '../../context/AuthProvider'

const Createtask = () => {

    const [userData,setUserData]=useContext(AuthContext)


    const [taskTitle, setTaskTitle] = useState('')
    const [taskDesc,setTaskDesc] = useState('')
    const [taskDate, setTaskDate] = useState('')
    const [asignTo, setAsignTo] = useState('')
    const [category, setCategory] = useState('')

    // const [newtask, setNewTask] = useState({})

    // two way binding 
    const submitHandler=(e)=>{
        e.preventDefault()

        // input se jo bhi values aayi he use storage me dalna he 
        // setNewTask({taskTitle,taskDesc,taskDate,category,active:false,newTask:true,failed:false,completed:false})
        
         const newTask = {
            taskTitle,
            taskDesc,
            taskDate,
            category,
            active: false,
            newTask: true,
            failed: false,
            completed: false,
        };

        const data = userData

        data.forEach((elem) => {
            if(asignTo.toLowerCase() == elem.firstName.toLowerCase()){
                // insert new task in the employee task list
                elem.tasks.push(newTask)  
                elem.taskCounts.newTask = elem.taskCounts.newTask + 1
            }
        });
        setUserData(data)
        
        // localStorage.setItem("employees", JSON.stringify(data))

        
        setAsignTo('')
        setCategory('')
        setTaskDate('')
        setTaskDesc('')
        setTaskTitle('')  
        
    }   
     
    
  return (
    <div className='mt-10 bg-[#1C1C1C] rounded p-5'>
        <form onSubmit={(e)=>{
            submitHandler(e)
        }} className='flex flex-col sm:flex-row sm:items-start items-center justify-between w-full'>
            {/* info div */}
            <div className='w-1/2 '>
                <div>
                    <h3 className='text-sm text-gray-300 mb-0.5'>Task Title</h3>
                    <input
                        required
                        value={taskTitle}
                        onChange={(e)=>{
                            setTaskTitle(e.target.value)
                        }} 
                        type="text" 
                        placeholder='Make a UI Design'
                        className='text-sm border-2 border-emerald-100 px-2 py-1 w-4/5 rounded  outline-none bg-transparent placeholder:text-gray-300 mb-4'                        />
                </div>

                <div>
                    <h3 className='text-sm text-gray-300 mb-0.5'>Date</h3>
                    <input 
                        required
                        value={taskDate}
                        onChange={(e)=>{
                            setTaskDate(e.target.value)
                        }} 
                        type="date" 
                        name="" 
                        id="" 
                        className='text-sm border-2 border-emerald-100 px-2 py-1 w-4/5 rounded  outline-none bg-transparent placeholder:text-gray-300 mb-4'                        />
                </div>

                <div>
                    <h3 className='text-sm text-gray-300 mb-0.5'>Assign to</h3>
                    <input 
                        required
                        value={asignTo}
                        onChange={(e)=>{
                            setAsignTo(e.target.value)
                        }} 
                        type="text" 
                        placeholder='Employee Name'
                        className='text-sm border-2 border-emerald-100 px-2 py-1 w-4/5 rounded  outline-none bg-transparent placeholder:text-gray-300 mb-4'
                    />
                </div>
                <div>
                    <h3 className='text-sm text-gray-300 mb-0.5'>Category</h3>
                    <input 
                        required
                        value={category}
                        onChange={(e)=>{
                            setCategory(e.target.value)
                        }} 
                        type="text" 
                        placeholder='design, dev, etc'
                        className='text-sm border-2 border-emerald-100 px-2 py-1 w-4/5 rounded  outline-none bg-transparent placeholder:text-gray-300 mb-4'
                    />
                </div>
            </div>
            {/* desc div */}
            <div className='w-1/2  flex  flex-col  items-start'>
                <h3 className='text-sm text-gray-300 mb-0.5'>Description</h3>
                <textarea 
                    required
                    value={taskDesc}
                    onChange={(e)=>{
                        setTaskDesc(e.target.value)
                    }} 
                    name="" 
                    id="" 
                    placeholder='Write Description of the Task' 
                    className='w-full h-44 text-sm py-2 px-4 border-2 border-emerald-100 rounded bg-transparent  outline-none placeholder:text-gray-300'
                >
                </textarea>
                <button className='border-none rounded px-5 py-3  bg-emerald-500 hover:bg-emerald-700 mt-4 text-sm w-full '>Create Task </button>
            </div>

        </form>
    </div>
  )
}

export default Createtask
