import React from 'react'
// component to show the task status 
const TaskListNum = ({data}) => {
  return (
    <div className='flex mt-10 screen flex-wrap justify-between gap-5'>
      <div className='rounded-xl w-[45%] px-9 py-6 bg-blue-400'>
        <h2 className='text-2xl font-semibold'>{data.taskCounts.newTask}</h2>
        <h3 className='font-medium text-xl'>New Task</h3>
      </div>
      <div className='rounded-xl w-[45%] px-9 py-6 bg-green-300'>
        <h2 className='text-2xl font-semibold'>{data.taskCounts.completed}</h2>
        <h3 className='font-medium text-xl'>Completed</h3>
      </div>
      <div className='rounded-xl w-[45%] px-9 py-6 bg-amber-300'>
        <h2 className='text-2xl font-semibold'>{data.taskCounts.active}</h2>
        <h3 className='font-medium text-xl'>Accepted</h3>
      </div>
      <div className='rounded-xl w-[45%] px-9 py-6 bg-red-400'>
        <h2 className='text-2xl font-semibold'>{data.taskCounts.failed}</h2>
        <h3 className='font-medium text-xl'>Failed</h3>
      </div>
    </div>
  )
}

export default TaskListNum
