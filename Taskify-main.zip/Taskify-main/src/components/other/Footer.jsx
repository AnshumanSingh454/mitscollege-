import React from 'react'

const Footer = () => {
  return (
    <div className='bg-[#1C1C1C] w-screen '>
      Hello
    </div>
  )
}

export default Footer
