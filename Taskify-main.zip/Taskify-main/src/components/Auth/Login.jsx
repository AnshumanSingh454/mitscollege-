import React, { useState } from 'react'

const Login = ({handleLogin}) => {
    
    // two way binding
    const [email,setEmail]=useState('');
    const[password,setPass]=useState('');
    
    const submithandler= (e)=>{
        e.preventDefault();
        // console.log('Email is ',email, ' pass is ',password);
        handleLogin(email,password);    //email password passed to validating function
        // now handle login will validate  this and render components accordingly
        setEmail('');
        setPass('');
    }
  return (
    <div className='flex items-center justify-center h-screen w-screen'>
      <div className='border-2 border-none p-20 shadow-lg shadow-emerald-600 rounded-2xl'>
         <form className='flex flex-col items-center justify-center' onSubmit={(e)=>{submithandler(e)}}>
            <input 
                value={email} 
                onChange={(e)=>{setEmail(e.target.value)}} 
                required type="email" placeholder='Email' name="" id="mail" className='border-2 border-emerald-600 rounded-full px-5 py-3  outline-none bg-transparent placeholder:text-gray-300'
            />
            <input
                value={password} 
                onChange={(e)=>{setPass(e.target.value)}}
                required type="password" placeholder='Password' name="" id="pass"  className='border-2 border-emerald-600 rounded-full px-5 py-3  outline-none bg-transparent mt-3 placeholder:text-gray-300'
            />
            <button className='border-none rounded-full px-5 py-3 outline-none bg-emerald-600 mt-3  w-[100%] '>Log in</button>
         </form>
      </div>
    </div>
  )
}

export default Login
