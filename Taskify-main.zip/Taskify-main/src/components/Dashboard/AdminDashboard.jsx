import React from 'react'
import Header from '../other/Header'
import Createtask from '../other/Createtask'
import AllTask from '../other/AllTask'
// create task function
const AdminDashboard = (props) => {
  return (
    <div className='p-7 h-screen w-full'>
        <Header changeUser={props.changeUser} />
        <Createtask/>
        <AllTask/>
    </div>
  )
}

export default AdminDashboard
