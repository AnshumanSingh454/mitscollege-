import React from 'react'
import Header from '../other/Header'
import TaskListNum from '../other/TaskListNum'
import TaskList from '../TaskList/TaskList'
import Footer from '../other/Footer'

const EmployeeDashboard = (props) => {
  // console.log(data)   //data --> email, password, id, taskArray
  return (
    <div className='bg-[#1C1C1C] h-screen p-7'>
      <Header changeUser={props.changeUser} data={props.data}/>
      <TaskListNum data={props.data}/>
      <TaskList data={props.data}/>
      
    </div>
  )
}

export default EmployeeDashboard
