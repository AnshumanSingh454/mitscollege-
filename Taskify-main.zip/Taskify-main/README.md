# Taskify - Employee Management System (EMS)

A functional and responsive frontend application for managing employees and their assigned tasks. This project is built with React and styled with Tailwind CSS, focusing on a clean user interface and practical, real-world functionality.



## Live Demo

[**[[](https://taskify-2jfkwoihm-akash-dixit-s-projects.vercel.app/)]**]

---

## Key Features

The application supports two distinct user roles with tailored functionalities:

### 👑 Admin (Employer) Features
* **Authentication**: Secure login for the admin.
* **Task Creation**: A dedicated form to create new tasks with a title, detailed description, deadline, and category.
* **Task Assignment**: Ability to assign tasks to specific employees from a predefined list.
* **Employee Overview**: A dashboard to view all employees and a summary of their task statuses (New, Active, Completed, Failed).
* **Persistent State**: User session is maintained, keeping the admin logged in even after a page refresh.

### 👨‍💼 Employee Features
* **Authentication**: Secure login for employees.
* **Personalized Dashboard**: A custom dashboard that displays only the tasks assigned to the logged-in employee.
* **Task Status Overview**: Cards summarizing the number of new, completed, accepted, and failed tasks.
* **Task Management**:
    * View all assigned tasks in a scrollable list.
    * **Accept** new tasks to move them to the active state.
    * Update the status of active tasks to **Completed** or **Failed**.
* **Persistent State**: The employee's login session is also maintained across page reloads.

---

## Technologies Used

This project is built using modern frontend technologies:

* **React.js**: A JavaScript library for building user interfaces.
* **Vite**: A next-generation frontend tooling for a faster and leaner development experience.
* **Tailwind CSS**: A utility-first CSS framework for rapid UI development.
* **React Context API**: For efficient state management and data passing throughout the application.
* **Browser Local Storage**: Used for data persistence (user sessions, tasks, employee data) in the absence of a backend.

---

## Project Structure

The project follows a modular and organized folder structure for better maintainability and scalability.

    src/
    |-- components/       # Reusable UI components
    |   |-- auth/
    |   |-- dashboard/
    |   |-- tasks/
    |-- context/          # React Context for state management
    |-- utils/            # Utility functions (e.g., localStorage helpers)
    |-- App.jsx
    |-- main.jsx


## Getting Started

To get a local copy up and running, follow these simple steps.

### Prerequisites

Make sure you have Node.js and npm installed on your machine.
* npm
    ```sh
    npm install npm@latest -g
    ```

### Installation

1.  Clone the repo
    ```sh
    git clone [https://github.com/your_username/your_repository_name.git](https://github.com/akashdixit05/taskify.git)
    ```
2.  Navigate to the project directory
    ```sh
    cd taskify
    ```
3.  Install NPM packages
    ```sh
    npm install
    ```
4.  Run the development server
    ```sh
    npm run dev
    ```
The application will be available at `http://localhost:5173` (or another port if 5173 is in use).


## Areas for Updation and Future Improvements

While the current version is fully functional as a frontend application, there are several areas for future improvement:

* **Backend Integration**:
    * Replace Local Storage with a proper backend (e.g., Node.js with Express).
    * Use a database like MongoDB or PostgreSQL for robust data management.
* **Enhanced Authentication**:
    * Implement JWT (JSON Web Tokens) for more secure authentication.
    * Add features like password reset and user registration.
* **Real-time Updates**:
    * Integrate WebSockets (e.g., using Socket.IO) to provide real-time updates for new tasks and status changes without needing a page refresh.
* **Advanced Features**:
    * Add a notification system for new task assignments and deadlines.
    * Implement a search and filter functionality for tasks.
    * Allow file attachments for tasks.
    * Create a "Create Member" feature for the admin to dynamically add new employees.
* **UI/UX Improvements**:
    * Add more animations and transitions for a smoother user experience.
    * Implement a dark mode toggle.
